-- Restior Stays Command Center cloud sync
-- Run this once in Supabase: SQL Editor -> New query -> paste -> Run.

create table if not exists public.restior_state (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.restior_state enable row level security;

-- Explicitly expose the table to the Supabase Data API roles.
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on table public.restior_state to anon, authenticated;

drop policy if exists "restior_state_select" on public.restior_state;
drop policy if exists "restior_state_insert" on public.restior_state;
drop policy if exists "restior_state_update" on public.restior_state;

create policy "restior_state_select"
on public.restior_state
for select
to anon, authenticated
using (id = 'main');

create policy "restior_state_insert"
on public.restior_state
for insert
to anon, authenticated
with check (id = 'main');

create policy "restior_state_update"
on public.restior_state
for update
to anon, authenticated
using (id = 'main')
with check (id = 'main');

grant select, insert, update on public.restior_state to anon, authenticated;
